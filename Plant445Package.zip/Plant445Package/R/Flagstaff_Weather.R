#' Flagstaff Weather Data
#'
#' A data table containing weather data from 2015 to 2019. The data was
#' collected every day from the flagstaff weather station. The source for this
#' data can be found at: https://www.ncdc.noaa.gov
#'
#'
#' @format A data frame with 1719 observations with 4 columns.
#' \describe{
#'    \item{DATE}{The date the information was recorded in year-month-day format.}
#'    \item{PRCP}{The amount of precipitation recorded in inches}
#'    \item{SNOW}{The amount of snow that fell recorded in inches}
#'    \item{TMAX}{The maximum temperature recorded that day}
#' }
"Flagstaff_Weather"
